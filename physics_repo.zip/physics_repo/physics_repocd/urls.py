from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from library import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.landing_page, name='landing_page'),
    path('library/', views.document_list, name='document_list'),
    path('document/<int:id>/', views.document_detail, name='document_detail'),
]

# This line allows PDFs to be viewed in the browser during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# This line allows static files to be served during development
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])