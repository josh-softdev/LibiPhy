from django.shortcuts import render, get_object_or_404
from .models import Document

def landing_page(request):
    """Landing page before library search"""
    total_documents = Document.objects.count()
    featured_documents = Document.objects.all()[:3]
    
    return render(request, 'library/landing.html', {
        'total_documents': total_documents,
        'featured_documents': featured_documents
    })

def document_list(request):
    """Main library search page"""
    query = request.GET.get('q')

    if query:
        documents = Document.objects.filter(title__icontains=query) | Document.objects.filter(author__icontains=query)
    else:
        documents = Document.objects.all()

    return render(request, 'library/document_list.html', {'documents': documents})

def document_detail(request, id):
    """Thesis detail page"""
    document = get_object_or_404(Document, id=id)
    return render(request, 'library/document_detail.html', {'document': document})